﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo4
{
    class Program
    {
        static void Main(string[] args)
        {
            bool entrada = true;

            do
            {
                try
                {
                    Console.WriteLine("Menu:");
                    Console.WriteLine("1. somar numeros");
                    Console.WriteLine("2. Converter de metros para milímetros");
                    Console.WriteLine("3. Calcula Aumento ");
                    Console.WriteLine("4. Calcula Desconto ");
                    Console.WriteLine("5. Aluguel Carro");
                    Console.WriteLine("6. Calcular IMC");
                    Console.WriteLine("7. Cantoneira até número fornecido");
                    Console.WriteLine("8. Tabuada de cada número ");
                    Console.WriteLine("9. Múltiplos de 3 entre 0 e 100");
                    Console.WriteLine("10. Fatoriais de 1 até 10");
                    Console.WriteLine("11. Imposto de Renda");
                    Console.WriteLine("12. Adivinhar número");
                    Console.WriteLine("13. Financiamento do veículo");
                    Console.WriteLine("14. Aposentadoria");
                    Console.WriteLine("15. Jogo da velha");
                    Console.WriteLine("0. Sair");
                    Console.Write("Escolha uma opção: ");
                    int escolha = int.Parse(Console.ReadLine());

                    switch (escolha)
                    {
                        case 8:
                            Console.Write("Digite um número (1 para estatico ou 2 para normal): ");
                            string entradA = Console.ReadLine();
                            int numero;

                            if (int.TryParse(entradA, out numero)) // Verifica se a entrada é um número válido
                            {
                                if (numero == 1)
                                {
                                    Console.Write("Digite um número para a tabuada: ");
                                    string Entrada = Console.ReadLine();
                                    int valor;
                                    if (int.TryParse(Entrada, out valor))
                                    {
                                        for (int i = 1; i <= 10; i++)
                                        {
                                            Console.WriteLine($"{valor} * {i} = {valor * i}");
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Por favor, digite um número válido.");
                                    }
                                }
                                else if (numero == 2)
                                {
                                    Console.Write("Digite um número para a tabuada: ");
                                    string entrad = Console.ReadLine();
                                    int valor;
                                    if (int.TryParse(entrad, out valor))
                                    {
                                        Tabuada tabuada = new Tabuada();
                                        tabuada.Calcular(valor);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Por favor, digite um número válido.");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Por favor, digite 1 ou 2.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Por favor, digite um número válido.");
                            }
                            break;
                        case 12:

                            {
                                Console.WriteLine("Vou pensar em um número entre 1 e 100. Tente adivinhar!");
                                Console.WriteLine("Digite 0 para sair:");

                                Random random = new Random(); // Cria um objeto para gerar números aleatórios
                                int numeroSecreto = random.Next(1, 101); // Gera um número aleatório entre 1 e 100
                                int tentativas = 0; // Contador de tentativas
                                bool acertou = false; // Variável para verificar se o jogador acertou

                                while (!acertou) // Loop até o jogador acertar
                                {
                                    Console.Write("Digite um número: ");
                                    string Entrada = Console.ReadLine();
                                    int palpite;

                                    if (int.TryParse(Entrada, out palpite)) // Verifica se a entrada é um número válido
                                    {
                                        if (palpite == 0)
                                        {
                                            Console.WriteLine("Você saiu do jogo.");
                                            break; // Sai do loop se o jogador digitar 0
                                        }

                                        tentativas++;
                                        if (palpite == numeroSecreto)
                                        {
                                            acertou = true;
                                            Console.WriteLine($"Parabéns! Você acertou o número secreto {numeroSecreto} em {tentativas} tentativas.");
                                        }
                                        else if (palpite < numeroSecreto)
                                        {
                                            Console.WriteLine("Muito baixo. Tente novamente.");
                                        }
                                        else
                                        {
                                            Console.WriteLine("Muito alto. Tente novamente.");
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Por favor, digite um número válido.");
                                    }
                                }
                            }
                            break;


                        case 0:
                            Console.WriteLine("Saindo do programa...");
                            entrada = false;
                            break;
                        default:
                            Console.WriteLine("Opção inválida. Tente novamente.");
                            break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Formato inválido. Tente novamente.");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Número muito grande. Tente novamente.");
                }
            } while (entrada);
        }
    }
}